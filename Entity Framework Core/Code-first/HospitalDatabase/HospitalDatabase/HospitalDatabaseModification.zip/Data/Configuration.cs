﻿namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-JH4M4M9\\MSSQLSERVER01;Database=HospitalDatabase;Integrated Security=true;";
    }
}
