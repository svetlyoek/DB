﻿namespace P03_SalesDatabase.Data
{
    public static class Connection
    {
        public const string ConnectionString = "Server=DESKTOP-JH4M4M9\\MSSQLSERVER01;Database=SalesDatabase;Integrated Security=true;";
    }
}
