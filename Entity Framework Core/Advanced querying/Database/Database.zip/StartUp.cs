﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class StartUp
    {

        public static void Main()
        {
            using (var db = new BookShopContext())
            {
                //DbInitializer.ResetDatabase(db);

                string input = Console.ReadLine();

                Console.WriteLine(GetBooksByCategory(db, input));
            }
        }

        //problem 01
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder sb = new StringBuilder();

            var age = Enum.Parse<AgeRestriction>(command, true);

            var bookTitles = context.Books
                .Where(b => b.AgeRestriction == age)
                .Select(b => new
                {
                    BookTitle = b.Title,
                })
                .OrderBy(b => b.BookTitle)
                .ToList();

            foreach (var t in bookTitles)
            {
                sb
                    .AppendLine(t.BookTitle);
            }

            return sb.ToString().TrimEnd();
        }

        //problem 02
        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var type = Enum.Parse<EditionType>("Gold");

            var booksTitles = context.Books
                .Where(b => b.Copies < 5000 && b.EditionType == type)
                .OrderBy(b => b.BookId)
                .Select(b => new
                {
                    BookTitle = b.Title
                })
                .ToList();

            foreach (var t in booksTitles)
            {
                sb
                    .AppendLine(t.BookTitle);
            }

            return sb.ToString().TrimEnd();

        }

        //problem 03
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var books = context.Books
                .Where(b => b.Price > 40)
                .Select(b => new
                {
                    BookTitle = b.Title,
                    BookPrice = b.Price
                })
                .OrderByDescending(b => b.BookPrice)
                .ToList();

            foreach (var b in books)
            {
                sb
                    .AppendLine($"{b.BookTitle} - ${b.BookPrice:f2}");
            }

            return sb.ToString().TrimEnd();
        }

        //problem 04
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            StringBuilder sb = new StringBuilder();

            var bookTitles = context.Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .Select(t => new
                {
                    BookTitle = t.Title
                })
                .ToList();

            foreach (var t in bookTitles)
            {
                sb
                    .AppendLine(t.BookTitle);
            }

            return sb.ToString().TrimEnd();
        }

        //problem 05
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            StringBuilder sb = new StringBuilder();

            var categories = input.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToList();
            var bookTitles = new List<string>();

            foreach (var category in categories)
            {
                var books = context.Books
                    .Where(b => b.BookCategories
                    .Any(bc => bc.Category.Name.ToLower() == category.ToLower()))
                    .Select(b => new
                    {
                        b.Title
                    })
                    .ToList();

                foreach (var book in books)
                {
                    bookTitles.Add(book.Title);
                }
            }

            foreach (var title in bookTitles.OrderBy(t => t))
            {
                sb
                    .AppendLine(title);
            }

            return sb.ToString().TrimEnd();
        }
    }

}
