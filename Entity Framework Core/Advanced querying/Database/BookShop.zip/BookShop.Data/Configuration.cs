﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-JH4M4M9\MSSQLSERVER01;Database=BookShop;Integrated Security=True;";
    }
}
